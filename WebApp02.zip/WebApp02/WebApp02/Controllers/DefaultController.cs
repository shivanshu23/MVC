﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApp02.Models;
using System.Data;

namespace WebApp02.Controllers
{
    public class DefaultController : Controller
    {
        string strconnect = string.Empty;

        public DefaultController()
        {
            strconnect = @"Data Source=SLW10161\SQLEXPRESS; Initial Catalog=AppDatabase; Integrated Security=True";
        }
        // GET: Default
        [HttpGet]
        public ActionResult HomePage(int? ID)
        {
            Properties prop = new Properties();
            if (ID != null)
            {
                using (SqlConnection connect_edit = new SqlConnection(strconnect))
                {
                    SqlCommand cmd_edit = new SqlCommand("[dbo].[selectUser]", connect_edit);
                    cmd_edit.CommandType = CommandType.StoredProcedure;
                    if (connect_edit.State != ConnectionState.Open)
                    {
                        connect_edit.Open();
                    }
                    cmd_edit.Parameters.AddWithValue("@user_id", ID);

                    SqlDataReader reader = cmd_edit.ExecuteReader();

                    while (reader.Read())
                    {
                        prop.ID = Convert.ToInt32(reader["ID"]);
                        prop.Salutation = Convert.ToString(reader["Salutation"]);
                        prop.First_name = Convert.ToString(reader["First_Name"]);
                        prop.Last_name = Convert.ToString(reader["Last_Name"]);
                        prop.Gender = Convert.ToString(reader["Gender"]);
                        prop.Comments = Convert.ToString(reader["Comments"]);
                        prop.DesigId = Convert.ToInt32(reader["Desg_ID"]);
                    }
                    connect_edit.Close();
                }
            }        
            using (SqlConnection connect = new SqlConnection(strconnect))
            {
                if (connect.State != ConnectionState.Open)
                {
                    connect.Open();
                }
                SqlCommand cmd = new SqlCommand("select * from Designation", connect);
                SqlDataReader reader2 = cmd.ExecuteReader();
                List<SelectListItem> deslist = new List<SelectListItem>();
                while (reader2.Read())
                {
                    deslist.Add(new SelectListItem()
                    {
                        Text = reader2["desg_Description"].ToString(),
                        Value = reader2["desg_ID"].ToString() });
                    }
                prop.desgDetails = deslist;
                connect.Close();
            }
            return View(prop);
        }

        [HttpPost]
        public ActionResult HomePage(Properties prop)
        {
            List<Properties> obj = new List<Properties>();
            using (SqlConnection connect = new SqlConnection(strconnect))
            {
                if (connect.State != ConnectionState.Open)
                {
                    connect.Open();
                }
                if (prop.ID == 0)
                {
                    int salutVal = prop.Salutation == "Mr" ? 1 : prop.Salutation == "Ms" ? 2 : 3;
                    int genderVal = prop.Gender == "Male" ? 1 : 2;
                    SqlCommand command = new SqlCommand("[dbo].[addUser]", connect);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Salutation", salutVal);
                    command.Parameters.AddWithValue("@First_Name", prop.First_name);
                    command.Parameters.AddWithValue("@Last_Name", prop.Last_name);
                    command.Parameters.AddWithValue("@Gender", genderVal);
                    command.Parameters.AddWithValue("@Comments", prop.Comments);
                    command.Parameters.AddWithValue("@Desg_ID", prop.DesigId);
                    int result = command.ExecuteNonQuery();
                    if (result > 0)
                    {
                        ViewBag.message = "data inserted.";
                    }
                }
                else
                {
                    //Update Operation
                    SqlCommand cmd_update = new SqlCommand("[dbo].[updateUser]", connect);
                    cmd_update.CommandType = CommandType.StoredProcedure;
                    int salutVal = prop.Salutation == "Mr" ? 1 : prop.Salutation == "Ms" ? 2 : 3;
                    int genderVal = prop.Gender == "Male" ? 1 : 2;
                    cmd_update.Parameters.AddWithValue("@identity", prop.ID);
                    cmd_update.Parameters.AddWithValue("@salutation", salutVal);
                    cmd_update.Parameters.AddWithValue("@first_name", prop.First_name);
                    cmd_update.Parameters.AddWithValue("@last_name", prop.Last_name);
                    cmd_update.Parameters.AddWithValue("@gender", genderVal);
                    cmd_update.Parameters.AddWithValue("@comments", prop.Comments);
                    cmd_update.Parameters.AddWithValue("@desg_id", prop.DesigId);
                    int res_update = cmd_update.ExecuteNonQuery();
                    if (res_update > 0)
                    {
                        ViewBag.message_update = "data updated.";
                    }                                      
                }
                SqlCommand cmd = new SqlCommand("select * from Designation", connect);
                SqlDataReader reader2 = cmd.ExecuteReader();
                List<SelectListItem> deslist = new List<SelectListItem>();
                while (reader2.Read())
                {
                    deslist.Add(new SelectListItem()
                    {
                        Text = reader2["desg_Description"].ToString(),
                        Value = reader2["desg_ID"].ToString()
                    });
                }
                prop.desgDetails = deslist;
                connect.Close();
            }
            return View(prop);

            //if (Session["userCollection"] != null)
            //{
            //    var objSession = Session["userCollection"] as List<Properties>;
            //    obj.AddRange(objSession);
            //    obj.Add(prop);
            //    Session["userCollection"] = obj;
            //}
            //else
            //{
            //    obj.Add(prop);
            //    Session["userCollection"] = obj;
            //}
        }

        public ActionResult DataPage(Properties prop)
        {
            DataTable dataset = new DataTable();
            using (SqlConnection connect = new SqlConnection(strconnect))
            {
                if (connect.State != ConnectionState.Open)
                {
                    connect.Open();
                }
                SqlCommand cmd = new SqlCommand("select * from UserDetails", connect);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dataset);
                connect.Close();
            }
            return View(dataset);
        }

        public ActionResult DeleteDataPage(int ID)
        {
            DataTable dataset = new DataTable();
            using (SqlConnection connect2 = new SqlConnection(strconnect))
            {
                if (connect2.State != ConnectionState.Open)
                {
                    connect2.Open();
                }
                SqlCommand cmd_delete = new SqlCommand("[dbo].[deleteUser]", connect2);
                cmd_delete.CommandType = CommandType.StoredProcedure;
                cmd_delete.Parameters.AddWithValue("@identity", ID);
                int del_user = cmd_delete.ExecuteNonQuery();
                connect2.Close();
            }
            return RedirectToAction("DataPage");
        }      
    }    
}

