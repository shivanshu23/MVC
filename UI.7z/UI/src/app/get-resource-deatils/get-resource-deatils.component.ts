import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Params, ActivatedRoute } from '@angular/router';
import '../get-all-resource/get-all-resource.component';


@Component({
  selector: 'app-get-resource-deatils',
  templateUrl: './get-resource-deatils.component.html',
  styleUrls: ['./get-resource-deatils.component.css']
})

export class GetResourceDeatilsComponent implements OnInit {
  id: any;
  public imagesUrl;

  constructor(private http: HttpClient, private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe(
      (params: Params) => {
        this.id = params["id"];
        if (this.id !== null && this.id !== '') {
          this.getResourceDetail();
        }
      }
    );
  }

  resourceDetail: any;
  getResourceDetail() {

    this.http.get("http://localhost:39521/api/resources/" + this.id)
      .subscribe(
        (data) => {
          this.resourceDetail = data;

          console.log(this.resourceDetail.body);
        }
      )
  }
}
