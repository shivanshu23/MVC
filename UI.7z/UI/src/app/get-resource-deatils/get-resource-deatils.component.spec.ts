import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetResourceDeatilsComponent } from './get-resource-deatils.component';

describe('GetResourceDeatilsComponent', () => {
  let component: GetResourceDeatilsComponent;
  let fixture: ComponentFixture<GetResourceDeatilsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetResourceDeatilsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetResourceDeatilsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
