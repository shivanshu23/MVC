import { Observable } from 'rxjs';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

import { HttpHeaders, HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { UserViewModel } from '../Model/UserModel';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  Token: string = "";
  constructor(private http: HttpClient) { }

  userViewModel: UserViewModel;

  login(Username: string, Password: string) {
    debugger;

    const user: UserViewModel = { userName: Username, userPassword: Password };

    return this.http.post("http://localhost:39521/api/Login", user)
      .map(user => {
        return user;
      });
  }
}