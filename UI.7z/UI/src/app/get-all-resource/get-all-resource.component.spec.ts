import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetAllResourceComponent } from './get-all-resource.component';

describe('GetAllResourceComponent', () => {
  let component: GetAllResourceComponent;
  let fixture: ComponentFixture<GetAllResourceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetAllResourceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetAllResourceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
