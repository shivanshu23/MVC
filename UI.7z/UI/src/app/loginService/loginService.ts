import { Observable } from 'rxjs';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

import { HttpHeaders, HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { UserViewModel } from '../Model/UserModel';

@Injectable()
export class loginService {

  Token: string = "";
  constructor(private http: HttpClient) { }

  userViewModel: UserViewModel;

  login(Username: string, Password: string) {
    debugger;

    let params = new HttpParams().set("userName", Username).set("userPassword", Password);

    return this.http.get("http://localhost:39521/api/Login", { params: params })
      .map(user => {
        // login successful if there's a jwt token in the response
        if (user) {
          // store user details and jwt token in local storage to keep user logged in between page refreshes
          localStorage.setItem('currentUser', JSON.stringify(user));
        }
        return user;
      });

  }
}