export interface UserViewModel
{
    userName : string ;
    userPassword : string ;
}