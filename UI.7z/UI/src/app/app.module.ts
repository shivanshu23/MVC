import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { GetAllResourceComponent } from './get-all-resource/get-all-resource.component';
import { GetResourceDeatilsComponent } from './get-resource-deatils/get-resource-deatils.component';
import { LoginComponent } from './login/login.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { LoginService } from '../app/Services/login.service';

const appRoutes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'resource', component: GetAllResourceComponent },
  { path: 'resourceDetails/:id', component: GetResourceDeatilsComponent },
  { path: 'signUp', component: SignUpComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    GetAllResourceComponent,
    GetResourceDeatilsComponent,
    LoginComponent,
    SignUpComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes) 
  ],
  providers: [LoginService],
  bootstrap: [AppComponent]
})
export class AppModule { }
