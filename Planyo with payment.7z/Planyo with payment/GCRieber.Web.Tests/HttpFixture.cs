﻿using System;
using System.Net.Http;
using GCRieber.API;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.Configuration;

namespace GCRieber.Web.Tests
{
    public class HttpFixture: IDisposable
    {
        private TestServer _server;
        private HttpClient _client;

        public void Dispose() {
            _client.Dispose();
            _server.Dispose();
        }

        public HttpClient GetClient() {
            if (_server == null)
            {
                var currentDomainBaseDirectory = AppDomain.CurrentDomain.BaseDirectory;

                _server = new TestServer(new WebHostBuilder()
                    .UseStartup<Startup>()
                    .UseEnvironment("Development")
                    .UseConfiguration(new ConfigurationBuilder()
                        .SetBasePath(currentDomainBaseDirectory + "../../../../GCRieber.Web")
                        .AddJsonFile("appsettings.json")
                        .AddJsonFile("appsettings.Development.json")
                        .Build()
                    ));
                    
                
                _client = _server.CreateClient();
            }
            return _client;
        }
    }
}
