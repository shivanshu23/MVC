﻿using Microsoft.AspNetCore.Http;

namespace GCRieber.Web.Tests.Fakes
{
    public class FakeHttpContextAccessor : IHttpContextAccessor
    {
        private HttpContext _httpContext;

        public HttpContext HttpContext
        {
            get => _httpContext??new DefaultHttpContext();
            set => _httpContext = value;
        }
    }
}