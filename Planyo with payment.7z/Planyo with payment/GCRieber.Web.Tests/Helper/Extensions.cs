﻿using GCRieber.API.Helpers;
using Microsoft.AspNetCore.Mvc;

namespace GCRieber.Web.Tests.Helper
{
    public static class Extensions
    {
        public static IResult AsIResult(this ActionResult<IResult> actionResult)
        {
            var objectResult = (ObjectResult) actionResult.Result;
            return (IResult) objectResult.Value;
        }
    }
}