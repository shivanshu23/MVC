﻿//using System;
//using System.Text;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Authentication.JwtBearer;
//using Microsoft.AspNetCore.Authorization;
//using Microsoft.Extensions.DependencyInjection;
//using Microsoft.IdentityModel.Tokens;

//namespace GCRieber.API
//{
//    public partial class Startup
//    {
//        /// <summary>
//        /// In development mode, we must ensure that unauthenticated users have access.
//        /// </summary>
//        /// <param name="services"></param>
//        private void ConfigureAuth(IServiceCollection services)
//        {
//            //services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
//            //       .AddJwtBearer(options =>
//            //       {
//            //           options.TokenValidationParameters = new TokenValidationParameters
//            //           {
//            //               ClockSkew = TimeSpan.FromMinutes(5),
//            //               RequireSignedTokens = true,
//            //               RequireExpirationTime = true,
//            //               ValidateLifetime = true,
//            //               ValidateIssuer = true,
//            //               ValidateAudience = true,
//            //               ValidateIssuerSigningKey = true,
//            //               ValidIssuer = Configuration["Jwt:Issuer"],
//            //               ValidAudience = Configuration["Jwt:Issuer"],
//            //               IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["SigningKey"]))
//            //           };
//            //       });


//            services.AddAuthentication(options =>
//            {
//                options.DefaultAuthenticateScheme = "Jwt";
//                options.DefaultChallengeScheme = "Jwt";

//            }).AddJwtBearer("Jwt", options =>
//            {
//                if (Configuration["AuthMethod"] == "local")
//                {
//                    options.TokenValidationParameters = new TokenValidationParameters
//                    {
//                        ValidateAudience = false,
//                        //ValidAudience = "the audience you want to validate",
//                        ValidateIssuer = false,
//                        //ValidIssuer = "the isser you want to validate",

//                        ValidateIssuerSigningKey = true,
//                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["SigningKey"])),

//                        ValidateLifetime = true, //validate the expiration and not before values in the token
//                        ClockSkew = TimeSpan.FromMinutes(5) //5 minute tolerance for the expiration date
//                    };

//                    options.Events = new JwtBearerEvents
//                    {
//                        OnTokenValidated = context =>
//                        {
//                            return Task.CompletedTask;
//                        },
//                        OnAuthenticationFailed = context =>
//                        {
//                            return Task.CompletedTask;
//                        }
//                    };
//                }
//                else
//                {
//                    throw new Exception("unknown authentication method: " + Configuration["AuthMethod"]);
//                }
//            });

//        }
//    }
//}