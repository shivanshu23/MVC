﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Security.Claims;
using System.Security.Principal;
using System.Threading.Tasks;
using GCRieber.API.Enums;
using GCRieber.API.Helpers;
using GCRieber.API.Helpers.Stripe;
using GCRieber.API.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using RestSharp;

namespace GCRieber.API.Controllers
{
    /// <summary>
    /// Booking's endpoint
    /// </summary>
    [Route("api")]
    [ApiController]
    [Authorize]
    public class BookingsController : ControllerBase
    {
        private readonly ILogger _logger;
        readonly IConfiguration _configuration;
        private readonly ClaimsPrincipal _principal;
        private readonly PlanyoApiClient _planyoApiClient;

        /// <summary>
        /// Bookings Controller
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="configuration"></param>
        /// <param name="principal"></param>
        public BookingsController(ILogger<ResourcesController> logger, IConfiguration configuration, IPrincipal principal)
        {
            _logger = logger;
            _configuration = configuration;
            _principal = principal as ClaimsPrincipal;
            _planyoApiClient = new PlanyoApiClient(_configuration);
        }

        /// <summary>
        /// List user reservations
        /// </summary>
        /// <returns>List of available Reservation</returns>
        [HttpGet("bookings")]
        [ProducesResponseType(typeof(List<Booking>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IResult>> ListReservation(DateTime startDateTime, DateTime endDateTime)
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                //var activeUserEmail = ((ClaimsIdentity)_principal.Identity).GetActiveUserEmail();
                var request = new RestRequest();
                request.AddParameter("start_time", startDateTime.ToString("yyyy-MM-dd HH:mm"));
                request.AddParameter("end_time", endDateTime.ToString("yyyy-MM-dd HH:mm"));
                request.AddParameter("user_email", "KarenBerg@dayrep.com");
                // for getting the pricing info for all reservations
                request.AddParameter("detail_level", (int)DetailLevels.PricingInfo);

                var response = await _planyoApiClient.ExecuteApiAsync<PlanyoResponseViewModel<BookingListViewModel>>(request, PlanyoEndpoints.ListReservations);
                if (response.ResponseCode == 0)
                {
                    result.Body = response.Data.Results;
                    result.Message = response.ResponseMessage;
                    result.StatusCode = HttpStatusCode.OK;
                    return StatusCode((int)result.StatusCode, result);
                }

                result.Status = Status.Fail;
                result.Message = response.ResponseMessage;
                result.StatusCode = HttpStatusCode.BadRequest;
                _logger.LogWarning(response.ResponseMessage);
                return StatusCode((int)HttpStatusCode.BadRequest, result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Got an error while listing bookings of user");
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
                return StatusCode((int)HttpStatusCode.InternalServerError, result);
            }
        }

        /// <summary>
        /// Delete booking
        /// </summary>
        /// <returns>Delete booking sucess message</returns>
        [HttpDelete]
        [Route("bookings/{bookingid}")]
        [ProducesResponseType(typeof(DeleteBookingDataViewModel), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IResult>> Delete(int bookingid)
        {
            var result = new Result
            {
                Operation = Operation.Delete,
                Status = Status.Success
            };
            try
            {
                //Get reservation data
                var dataResponse = await GetBookingData(bookingid);
                // Case if booking exists
                if (dataResponse.ResponseCode == 0)
                {
                    var activeUserEmail = ((ClaimsIdentity)_principal.Identity).GetActiveUserEmail();
                    if (dataResponse.Data.Email.ToLower() == activeUserEmail.ToLower())
                    {
                        if ((dataResponse.Data.Status == ReservationStatus.CancelledByClient)
                                          || (dataResponse.Data.Status == ReservationStatus.CancelledAndRefunded)
                                          || (dataResponse.Data.Status == ReservationStatus.CancelledByAdmin))
                        {
                            result.Status = Status.Fail;
                            result.Message = "Booking is already cancelled";
                            result.StatusCode = HttpStatusCode.OK;
                            _logger.LogWarning(result.Message);
                            return StatusCode((int)HttpStatusCode.OK, result);
                        }

                        // check for cancel booking before one hour or past bookings
                        var bufferHours = dataResponse.Data.StartTime.Subtract(DateTime.Now);
                        if (bufferHours.TotalHours <= 1)
                        {
                            result.Status = Status.Fail;
                            result.Message = "Either only one hour is left for booking to start or you are trying to delete a past booking";
                            result.StatusCode = HttpStatusCode.OK;
                            return StatusCode((int)HttpStatusCode.OK, result);
                        }

                        //Fetching list of payments of booking
                        var paymentResponse = await ListBookingPayments(bookingid);

                        //Booking with no payment
                        if (paymentResponse.Data.Results.Count == 0)
                        {
                            var cancelReservationResponse = await DeleteBooking(bookingid);
                            result.Body = cancelReservationResponse.Data;
                            result.Message = cancelReservationResponse.ResponseMessage;
                            result.StatusCode = HttpStatusCode.OK;
                            return StatusCode((int)result.StatusCode, result);
                        }

                        var paymentHelper = new PaymentHelper(_configuration);

                        //for multiple Payments
                        foreach (var paymentStatus in paymentResponse.Data.Results)
                        {
                            if (paymentStatus.PaymentStatus == 1)
                            {
                                //Make a refund for your booking
                                var refund = paymentHelper.MakeRefund((long)dataResponse.Data.AmountPaid, paymentStatus.TransactionId);

                                if (refund.Status == "succeeded")
                                {
                                    //Delete Booking
                                    var cancelReservationResponse = await DeleteBooking(bookingid);
                                    if (cancelReservationResponse.ResponseCode == 0)
                                    {
                                        //set payment response in planyo
                                        var addRefundDetailResponse = await ManagePaymentResponse(bookingid, paymentHelper.StripeCodeForPlanyo, PaymentStatus.Refund,
                                                                                                   refund.Status, refund.Id, refund.Amount.ToString(), refund.Currency);

                                        // Update refund on stripe
                                        var updatedRefundDetails = paymentHelper.UpdateRefundDetails(refund.Id,
                                        new Dictionary<string, string> {
                                                 { "resourceid", dataResponse.Data.ResourceId.ToString() },
                                                 { "reservationid", bookingid.ToString() },
                                                 { "paymentid", addRefundDetailResponse }
                                        });

                                        var msgStr = $"Booking cancelled with id {bookingid} and refund has been successfully initiated with id {refund.Id}. Refund payment details updated with id {addRefundDetailResponse}";
                                        result.Status = Status.Success;
                                        result.Body = cancelReservationResponse.Data;
                                        result.Message = msgStr;
                                        result.StatusCode = HttpStatusCode.OK;
                                        return StatusCode((int)result.StatusCode, result);
                                    }

                                    result.Status = Status.Fail;
                                    result.Message = cancelReservationResponse.ResponseMessage;
                                    result.StatusCode = HttpStatusCode.BadRequest;
                                    _logger.LogWarning(result.Message);
                                    return StatusCode((int)HttpStatusCode.BadRequest, result);
                                }
                            }
                        }
                    }
                    result.Status = Status.Fail;
                    result.Message = "You are not authorize to delete other user's booking";
                    result.StatusCode = HttpStatusCode.OK;
                    _logger.LogWarning(result.Message);
                    return StatusCode((int)HttpStatusCode.OK, result);
                }
                result.Status = Status.Fail;
                result.Message = dataResponse.ResponseMessage;
                result.StatusCode = HttpStatusCode.OK;
                _logger.LogWarning(result.Message);
                return StatusCode((int)HttpStatusCode.OK, result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Got an error while deleting booking");
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
                return StatusCode((int)HttpStatusCode.InternalServerError, result);
            }
        }

        private async Task<PlanyoResponseViewModel<DeleteBookingDataViewModel>> DeleteBooking(int bookingid)
        {
            var request = new RestRequest();
            request.AddParameter("reservation_id", bookingid);
            //parameter for user cancelling the booking.
            request.AddParameter("action", ReservationActions.UserCancel);
            var cancelReservationResponse = await _planyoApiClient.ExecuteApiAsync<PlanyoResponseViewModel<DeleteBookingDataViewModel>>(request, PlanyoEndpoints.DoReservationAction);

            return cancelReservationResponse;
        }

        private async Task<PlanyoResponseViewModel<BookingInformationResponseViewModel>> GetBookingData(int bookingid)
        {
            var request = new RestRequest();
            request.AddParameter("reservation_id", bookingid);
            var dataResponse = await _planyoApiClient.ExecuteApiAsync<PlanyoResponseViewModel<BookingInformationResponseViewModel>>(request, PlanyoEndpoints.GetReservationData);

            return dataResponse;
        }

        private async Task<PlanyoResponseViewModel<BookingPaymentViewModel>> ListBookingPayments(int bookingid)
        {
            var request = new RestRequest();
            request.AddParameter("reservation_id", bookingid);
            var paymentResponse = await _planyoApiClient.ExecuteApiAsync<PlanyoResponseViewModel<BookingPaymentViewModel>>(request, PlanyoEndpoints.GetReservationPayments);

            return paymentResponse;
        }


        /// <summary>
        /// Modify User's Booking
        /// </summary>
        /// <returns>Modify booking sucess message</returns>
        [HttpPut]
        [Route("bookings/{bookingid}")]
        [ProducesResponseType(typeof(UpdateBookingResponseViewModel), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IResult>> ModifyBookings(int bookingid, [FromBody] UpdateBookingViewModel modifybooking)
        {
            var result = new Result
            {
                Operation = Operation.Update,
                Status = Status.Success
            };
            try
            {
                var request = new RestRequest();
                request.AddParameter("reservation_id", bookingid);
                var dataResponse = await _planyoApiClient.ExecuteApiAsync<PlanyoResponseViewModel<Booking>>(request, PlanyoEndpoints.GetReservationData);
                if (dataResponse.ResponseCode == 0)
                {
                    var activeUserEmail = ((ClaimsIdentity)_principal.Identity).GetActiveUserEmail();
                    if (dataResponse.Data.Email == activeUserEmail)
                    {
                        if (dataResponse.Data.Status == ReservationStatus.CancelByUser) // other cancel checks
                        {
                            result.Status = Status.Fail;
                            result.Message = "Cancelled bookings cannot be modified";
                            result.StatusCode = HttpStatusCode.OK;
                            _logger.LogWarning(result.Message);
                            return StatusCode((int)HttpStatusCode.OK, result);
                        }
                        // Update booking details
                        request = new RestRequest();
                        request.AddParameter("reservation_id", bookingid);
                        request.AddParameter("resource_id", modifybooking.ResourceId);
                        request.AddParameter("start_time", modifybooking.StartTime.ToString("yyyy-MM-dd HH:mm"));
                        request.AddParameter("end_time", modifybooking.EndTime.ToString("yyyy-MM-dd HH:mm"));
                        request.AddParameter("prop_res_location", modifybooking.Location);

                        var updateBookingResponse = await _planyoApiClient.ExecuteApiAsync<PlanyoResponseViewModel<UpdateBookingResponseViewModel>>(request, PlanyoEndpoints.ModifyReservation);
                        if (updateBookingResponse.ResponseCode == 0)
                        {
                            result.Body = updateBookingResponse.Data;
                            result.Message = updateBookingResponse.ResponseMessage;
                            result.StatusCode = HttpStatusCode.OK;
                            return StatusCode((int)result.StatusCode, result);
                        }
                        result.Status = Status.Fail;
                        result.Message = updateBookingResponse.ResponseMessage;
                        result.StatusCode = HttpStatusCode.BadRequest;
                        _logger.LogWarning(result.Message);
                        return StatusCode((int)HttpStatusCode.BadRequest, result);
                    }
                    result.Status = Status.Fail;
                    result.Message = "You are not authorize to modify other user's booking";
                    result.StatusCode = HttpStatusCode.OK;
                    _logger.LogWarning(result.Message);
                    return StatusCode((int)HttpStatusCode.OK, result);
                }
                result.Status = Status.Fail;
                result.Message = dataResponse.ResponseMessage;
                result.StatusCode = HttpStatusCode.BadRequest;
                _logger.LogWarning(result.Message);
                return StatusCode((int)HttpStatusCode.BadRequest, result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Error while modifying booking");
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
                return StatusCode((int)HttpStatusCode.InternalServerError, result);
            }
        }

        /// <summary>
        /// New booking
        /// </summary>
        /// <returns>Make a new booking</returns>
        [HttpPost("bookings/{resourceid}")]
        [ProducesResponseType(typeof(BookingResponseViewModel), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IResult>> Bookings(int resourceid, [FromBody] BookingViewModel booking)
        {
            var result = new Result
            {
                Operation = Operation.Create,
                Status = Status.Success
            };
            try
            {
                var activeUserEmail = ((ClaimsIdentity)_principal.Identity).GetActiveUserEmail();
                // can make booking
                var canMakeBookingData = await CanMakeBooking(resourceid, booking);
                if (canMakeBookingData.IsReservationPossible)
                {
                    // User set up
                    if (await UserSetup(booking.FirstName, activeUserEmail))
                    {
                        // Get rental info
                        var rentalInfo = await GetRentalInfo(resourceid, booking);

                        if (rentalInfo.Total == 0)
                        {
                            result.Status = Status.Fail;
                            result.Message = "Price should be greater than 0 NOK";
                            result.StatusCode = HttpStatusCode.OK;
                            return StatusCode((int)HttpStatusCode.OK, result);
                        }

                        // Make payment on stripe
                        var bookingPaymentInfoViewModel = new BookingPaymentInfoViewModel();
                        var paymentHelper = new PaymentHelper(_configuration);
                        var charge = paymentHelper.MakePayment(booking.Token, Convert.ToInt64(rentalInfo.Total),
                                                                rentalInfo.Currency, activeUserEmail);
                        if (charge.Paid)
                        {
                            bookingPaymentInfoViewModel.ChargeId = charge.Id;
                            // Make booking
                            var reservationResponse = await MakeBooking(resourceid, activeUserEmail, booking);
                            if (reservationResponse.ResponseCode == 0)
                            {
                                bookingPaymentInfoViewModel.ReservationId = reservationResponse.Data.ReservationId;
                                // set payment response in planyo
                                var addPaymentDetailResponse = await ManagePaymentResponse(reservationResponse.Data.ReservationId, paymentHelper.StripeCodeForPlanyo, PaymentStatus.Successful,
                                                                                            charge.Status, charge.Id, charge.Amount.ToString(), charge.Currency);

                                bookingPaymentInfoViewModel.PaymentId = addPaymentDetailResponse;
                                // Update charge on stripe
                                var updatedChargeDetails = paymentHelper.UpdatePaymentDetails(charge.Id,
                                $"Booking payment of resource {resourceid} with reservation id {reservationResponse.Data.ReservationId}",
                                new Dictionary<string, string> {
                                    { "resourceid", resourceid.ToString() },
                                    { "reservationid", reservationResponse.Data.ReservationId.ToString() },
                                    { "paymentid", addPaymentDetailResponse }
                                });

                                var msgStr = $"Booking created with id {reservationResponse.Data.ReservationId} and payment is successfull with charge id {charge.Id}. Reservation payment detail updated with id {addPaymentDetailResponse}";
                                result.Status = Status.Success;
                                result.Message = msgStr;
                                result.Body = bookingPaymentInfoViewModel;
                                result.StatusCode = HttpStatusCode.OK;
                                return StatusCode((int)HttpStatusCode.OK, result);
                            }
                        }

                        else
                        {
                            result.Status = Status.Fail;
                            result.Message = "Booking not created as payment failed";
                            result.StatusCode = HttpStatusCode.OK;
                            return StatusCode((int)HttpStatusCode.OK, result);
                        }

                    }
                }
                result.Status = Status.Fail;
                result.Message = canMakeBookingData.ProblemTime + " " + canMakeBookingData.Reason;
                result.StatusCode = HttpStatusCode.OK;
                return StatusCode((int)HttpStatusCode.OK, result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Error while creating booking");
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
                return StatusCode((int)HttpStatusCode.InternalServerError, result);
            }
        }

        /// <summary>
        /// Check booking is avialable or not
        /// return the total amount if booking is available
        /// </summary>
        /// <param name="resourceid"></param>
        /// <param name="booking"></param>
        /// <returns></returns>
        private async Task<CanMakeReservationViewModel> CanMakeBooking(int resourceid, BookingViewModel booking)
        {
            var request = new RestRequest();
            request.AddParameter("resource_id", resourceid);
            request.AddParameter("start_time", booking.StartDate.ToString("yyyy-MM-dd HH:mm"));
            request.AddParameter("end_time", booking.EndDate.ToString("yyyy-MM-dd HH:mm"));
            request.AddParameter("quantity", booking.Quantity);
            var canMakeReservationResponse = await _planyoApiClient.ExecuteApiAsync<PlanyoResponseViewModel<CanMakeReservationViewModel>>(request,
                PlanyoEndpoints.CanMakeReservation);
            return canMakeReservationResponse.Data;
        }

        /// <summary>
        /// Create user if user not found
        /// </summary>
        /// <param name="firstName"></param>
        /// <param name="email"></param>
        /// <returns></returns>
        private async Task<bool> UserSetup(string firstName, string email)
        {
            var request = new RestRequest();
            request.AddParameter("email", email);
            var userDataResponse = await _planyoApiClient.ExecuteApiAsync<PlanyoResponseViewModel<UserDataViewModel>>(request, PlanyoEndpoints.GetUserData);
            request.AddParameter("first_name", firstName);
            //if user doesn't exist; create user
            if (userDataResponse.ResponseCode != 0)
            {
                var addUserResponse = await _planyoApiClient.ExecuteApiAsync<PlanyoResponseViewModel<CreateUserResponseViewModel>>(request, PlanyoEndpoints.AddUser);
                return addUserResponse.ResponseCode != 0 ? false : true;
            }
            return true;
        }

        /// <summary>
        /// Get booking rental info
        /// </summary>
        /// <param name="resourceid"></param>
        /// <param name="booking"></param>
        /// <returns></returns>
        private async Task<BookingRentalInfoViewModel> GetRentalInfo(int resourceid, BookingViewModel booking)
        {
            var request = new RestRequest();
            request.AddParameter("resource_id", resourceid);
            request.AddParameter("start_time", booking.StartDate.ToString("yyyy-MM-dd HH:mm"));
            request.AddParameter("end_time", booking.EndDate.ToString("yyyy-MM-dd HH:mm"));
            request.AddParameter("quantity", booking.Quantity);
            var rentalInfoResponse = await _planyoApiClient.ExecuteApiAsync<PlanyoResponseViewModel<BookingRentalInfoViewModel>>(request,
                PlanyoEndpoints.GetRentalPrice);
            return rentalInfoResponse.Data;
        }

        private async Task<PlanyoResponseViewModel<BookingResponseViewModel>> MakeBooking(int resourceid, string email, BookingViewModel booking)
        {
            var request = new RestRequest();
            request.AddParameter("email", email);
            request.AddParameter("resource_id", resourceid);
            request.AddParameter("start_time", booking.StartDate.ToString("yyyy-MM-dd HH:mm"));
            request.AddParameter("end_time", booking.EndDate.ToString("yyyy-MM-dd HH:mm"));
            request.AddParameter("quantity", booking.Quantity);
            request.AddParameter("first_name", booking.FirstName);
            request.AddParameter("last_name", booking.LastName);
            var reservationResponse = await _planyoApiClient.ExecuteApiAsync<PlanyoResponseViewModel<BookingResponseViewModel>>(request,
                PlanyoEndpoints.MakeReservation);
            return reservationResponse;
        }

        /// <summary>
        /// Add Reservation payment details
        /// </summary>       
        /// <param name="reservationId"></param>
        /// <param name="paymentMode"></param>
        /// <param name="status"></param>
        /// <param name="responseCode"></param>
        /// <param name="transactionId"></param>
        /// <param name="amount"></param>
        /// <param name="currency"></param>
        /// <returns></returns>
        private async Task<string> ManagePaymentResponse(int reservationId, int paymentMode, PaymentStatus status, string responseCode, string transactionId, string amount, string currency)
        {
            var request = new RestRequest();
            request.AddParameter("reservation_id", reservationId);
            request.AddParameter("payment_mode", paymentMode);
            request.AddParameter("payment_status", (int)status);
            request.AddParameter("payment_response_code", responseCode);
            request.AddParameter("transaction_id", transactionId);
            request.AddParameter("amount", amount);
            request.AddParameter("currency", currency.ToUpper());
            var response = await _planyoApiClient.ExecuteApiAsync<PlanyoResponseViewModel<BookingPaymentResponseViewModel>>(request, PlanyoEndpoints.AddReservationPayment);
            return response.ResponseCode == 0 ? response.Data.Payment_id : string.Empty;
        }

        /// <summary>
        /// Get Reservation Data
        /// </summary>
        /// <returns>List all the information about reservation</returns>
        [HttpGet("bookings/{bookingid}")]
        [ProducesResponseType(typeof(BookingInformationResponseViewModel), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IResult>> ReservationData(int bookingid)
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var request = new RestRequest();

                request.AddParameter("reservation_id", bookingid);

                var response = await _planyoApiClient.ExecuteApiAsync<PlanyoResponseViewModel<BookingInformationResponseViewModel>>(request, PlanyoEndpoints.GetReservationData);
                if (response.ResponseCode == 0)
                {
                    result.Body = response.Data;
                    result.Message = response.ResponseMessage;
                    result.StatusCode = HttpStatusCode.OK;
                    return StatusCode((int)result.StatusCode, result);
                }

                result.Status = Status.Fail;
                result.Message = response.ResponseMessage;
                result.StatusCode = HttpStatusCode.OK;
                _logger.LogWarning(response.ResponseMessage);
                return StatusCode((int)HttpStatusCode.OK, result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Got an error while fetching reservation data");
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
                return StatusCode((int)HttpStatusCode.InternalServerError, result);
            }
        }
    }
}