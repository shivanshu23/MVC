﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Security.Principal;
using System.Threading.Tasks;
using GCRieber.API.Enums;
using GCRieber.API.Helpers;
using GCRieber.API.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using RestSharp;

namespace GCRieber.API.Controllers
{
    /// <summary>
    /// Resource's endpoint
    /// </summary>
    [Route("api")]
    [ApiController]
    [Authorize]
    public class LocationsController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly IConfiguration _configuration;
        private readonly PlanyoApiClient _planyoApiClient;

        /// <summary>
        /// Locations Controller
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="configuration"></param>
        public LocationsController(ILogger<ResourcesController> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
            _planyoApiClient = new PlanyoApiClient(_configuration);
        }

        /// <summary>
        /// Retrieves all the resource locations
        /// </summary>
        /// <returns>List of available locations</returns>
        [HttpGet("locations")]
        [ProducesResponseType(typeof(List<string>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.InternalServerError)]
        public async Task<ActionResult<IResult>> Get()
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var request = new RestRequest();
                request.AddParameter("detail_level", (int)ResourceDetailLevels.ResourceProperties);
                var response = await _planyoApiClient.ExecuteApiAsync<PlanyoResponseViewModel<ResourceDataViewModel>>(request, PlanyoEndpoints.ListResources);
                if (response.ResponseCode == 0)
                {
                    if (!EnumerableExtensions.Any(response.Data.Resources))
                        return StatusCode((int)result.StatusCode, result);
                    var locations = (from resourceItemViewModel in response.Data.Resources
                                     where resourceItemViewModel.Value.Properties != null
                                     select resourceItemViewModel.Value.Properties.Location).ToList();

                    result.Body = locations.Distinct();
                    result.Message = response.ResponseMessage;
                    result.StatusCode = HttpStatusCode.OK;
                    return StatusCode((int)result.StatusCode, result);
                }

                result.Status = Status.Fail;
                result.Message = response.ResponseMessage;
                result.StatusCode = HttpStatusCode.BadRequest;
                _logger.LogWarning(response.ResponseMessage);
                return StatusCode((int)HttpStatusCode.BadRequest, result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Got an error when trying to retrieve list of locations");
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
                return StatusCode((int)HttpStatusCode.InternalServerError, result);
            }
        }

    }

}