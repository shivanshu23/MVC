﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using GCRieber.API.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace GCRieber.Web.Controllers
{
    /// <summary>
    /// Login contoller
    /// </summary>
    [Route("api/[controller]")]
    [Produces("application/json")]
    [ApiController]
    [AllowAnonymous]
    public class LoginController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        /// <summary>
        /// Initializes a new instance of the
        /// </summary>
        /// <param name="configuration">Configuration.</param>
        public LoginController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        /// <summary>
        /// Logins the user.
        /// </summary>
        /// <returns>Access token for the logged in user</returns>
        /// <param name="loginViewModel">Login view model.</param>
        [AllowAnonymous]
        [HttpPost]
        public IActionResult LoginUser([FromBody]UserLoginViewModel loginViewModel)
        {
            UserViewModel userView = null;
            if (loginViewModel.UserName == "test" && loginViewModel.UserPassword == "test")
            {
                userView = new UserViewModel
                {
                    UserId = "U3014225",
                    FirstName = "Karen",
                    LastName = "Berg",
                    Mail = "KarenBerg@dayrep.com"
                };
            }
            if (userView == null)
                return Unauthorized();
            userView.Token = GenerateToken(userView);
            return new ObjectResult(userView);
        }

        #region Private methods

        private string GenerateToken(UserViewModel user)
         {
            var claims = new Claim[]
            {
                new Claim("FirstName", user.FirstName),
                new Claim("LastName",user.LastName),
                new Claim(ClaimTypes.Email,user.Mail),
                new Claim(JwtRegisteredClaimNames.Nbf, new DateTimeOffset(DateTime.Now).ToUnixTimeSeconds().ToString()),
                new Claim(JwtRegisteredClaimNames.Exp, new DateTimeOffset(DateTime.Now.AddMinutes(3)).ToUnixTimeSeconds().ToString()),
            };

            JwtSecurityToken token = new JwtSecurityToken(
                new JwtHeader(new SigningCredentials(
                    new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["SigningKey"])),
                    SecurityAlgorithms.HmacSha256)),
                new JwtPayload(claims));

            //After creating an instance of JwtSecurityToken, call the WriteToken method of an instance of JwtSecurityTokenHandler and pass the JwtSecurityToken as a parameter:
            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        #endregion
    }
}