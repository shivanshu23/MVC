﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using GCRieber.API.Enums;
using GCRieber.API.Helpers;
using GCRieber.API.Helpers.AzureBlobHelper;
using GCRieber.API.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using RestSharp.Extensions;

namespace GCRieber.API.Controllers
{
    /// <summary>
    /// Content Api
    /// </summary>
    [Route("api/content")]
    [ApiController]
    [Authorize]
    public class ContentController : ControllerBase
    {
        private readonly ILogger _logger;
        readonly IConfiguration _configuration;
        private readonly AzureBlobFileProvider _azureBlobFileProvider;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="configuration"></param>
        public ContentController(ILogger<ResourcesController> logger, IConfiguration configuration)
        {
            _logger = logger;
            _configuration = configuration;
            _azureBlobFileProvider = new AzureBlobFileProvider(new AzureBlobOptions { ConnectionString = _configuration["AzureStorage:ConnectionString"], DocumentContainer = "content" });
        }

        /// <summary>
        /// Content of Index json file
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [ProducesResponseType(typeof(List<ContentViewModel>), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.InternalServerError)]
        public IActionResult Get([FromQuery]string tag)
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var fileInfo = _azureBlobFileProvider.GetFileInfo("index.json");
                if (fileInfo != null)
                {
                    string fileContent;
                    using (var reader = new StreamReader(fileInfo.CreateReadStream()))
                    {
                        fileContent = reader.ReadToEnd();
                    }
                    if (!string.IsNullOrEmpty(fileContent))
                    {
                        var obj = JsonConvert.DeserializeObject<ContentFileResponseViewModel>(fileContent);
                        result.Body = !string.IsNullOrEmpty(tag) ? obj.Data.Where(t => t.Tag.Contains(tag)).ToList() : obj.Data;
                        result.StatusCode = HttpStatusCode.OK;
                        return StatusCode((int)result.StatusCode, result);
                    }
                }
                result.Status = Status.Fail;
                result.Message = "No file or file data found";
                result.StatusCode = HttpStatusCode.BadRequest;
                _logger.LogWarning(result.Message);
                return StatusCode((int)HttpStatusCode.BadRequest, result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Got error while reading index.json file");
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
                return StatusCode((int)HttpStatusCode.InternalServerError, result);
            }
        }

        /// <summary>
        /// Content of Index json file
        /// </summary>
        /// <returns></returns>
        [HttpGet("binary")]
        [ProducesResponseType(typeof(BlobFileInfoViewModel), (int)HttpStatusCode.PartialContent)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.InternalServerError)]
        public IActionResult GetFile([FromQuery]string path)
        {
            var result = new Result
            {
                Operation = Operation.Read,
                Status = Status.Success
            };
            try
            {
                var fileInfo = _azureBlobFileProvider.GetFileInfo(path);
                if (fileInfo != null)
                {
                    var blobFileInfoViewModel = new BlobFileInfoViewModel
                    {
                        FileInfo = fileInfo,
                        //  FileBytes = fileInfo.CreateReadStream().ReadAsBytes(),
                        FileContent = Convert.ToBase64String(fileInfo.CreateReadStream().ReadAsBytes())
                    };
                    result.Body = blobFileInfoViewModel;
                    result.StatusCode = HttpStatusCode.OK;
                    return StatusCode((int)result.StatusCode, result);
                }
                result.Status = Status.Fail;
                result.Message = "No file or file data found";
                result.StatusCode = HttpStatusCode.BadRequest;
                _logger.LogWarning(result.Message);
                return StatusCode((int)HttpStatusCode.BadRequest, result);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Got error while reading index.json file");
                result.Message = e.Message;
                result.Status = Status.Error;
                result.StatusCode = HttpStatusCode.InternalServerError;
                return StatusCode((int)HttpStatusCode.InternalServerError, result);
            }
        }

    }
}