﻿using System.Net;
using GCRieber.API.Enums;
using GCRieber.API.Helpers;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;

namespace GCRieber.API.Controllers
{
    /// <summary>
    /// Diagnostic's endpoint
    /// </summary>
    [Produces("application/json")]
    [Route("api/diagnostic")]
    [ApiController]
    public class DiagnosticController : ControllerBase
    {
        private readonly IHostingEnvironment _environment;

        /// <summary>
        /// Controller
        /// </summary>
        /// <param name="environment"></param>
        public DiagnosticController(IHostingEnvironment environment)
        {
            _environment = environment;
        }

        /// <summary>
        /// For fetching details about the current environment
        /// </summary>
        /// <returns></returns>
        [HttpGet("environment")]
        [ProducesResponseType(typeof(IResult), (int)HttpStatusCode.OK)]
        public ActionResult<IResult> Get()
        {
            var result = new Result { Status = Status.Success, Message = "GCRieber API is running in environment " + _environment.EnvironmentName, Body = _environment.EnvironmentName, Operation = Operation.Read, StatusCode = HttpStatusCode.OK };
            return Ok(result);
        }
    }
}
