﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace GCRieber.API.ViewModels
{
    /// <summary>
    /// Resource data view model
    /// </summary>
    public class ResourceDetailViewModel
    {
        /// <summary>
        /// Resource name
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// Resource name translated to the language passed.
        /// </summary>
        [JsonProperty("translated_name")]
        public string TranslatedName { get; set; }

        /// <summary>
        /// Number of units available
        /// </summary>
        [JsonProperty("quantity")]
        public int Quantity { get; set; }


        /// <summary>
        /// Resource-specific properties 
        /// </summary>
        [JsonProperty("properties")]
        public Properties Properties { get; set; }

        private List<Photo> _photos;
        /// <summary>
        /// Photos Array with photoId as key
        /// </summary>
        [JsonProperty("photos")]
        public dynamic Photos
        {
            get
            {
                return _photos;
            }
            set
            {
                if (value == null)
                {
                    _photos = new List<Photo>();
                }
                else
                {
                    List<Photo> photos = new List<Photo>();
                    foreach (KeyValuePair<string, object> val in value)
                    {
                        var photo = new Photo();
                        var item = (Dictionary<string, Object>)val.Value;
                        foreach (KeyValuePair<string, object> itm in item)
                        {
                            if (itm.Key.Contains("id"))
                                photo.Id = Convert.ToInt32(itm.Value);
                            if (itm.Key.Contains("path"))
                                photo.Path = Convert.ToString(itm.Value);
                            if (itm.Key.Contains("title"))
                                photo.Title = Convert.ToString(itm.Value);
                        }
                        photos.Add(photo);
                    }
                    _photos = photos;
                }

            }
        }

        /// <summary>
        /// Base time unit of the resource
        /// </summary>
        [JsonProperty("time_unit")]
        public int TimeUnit { get; set; }


        /// <summary>
        /// Resource is available on working days from this time
        /// </summary>
        [JsonProperty("start_hour")]
        public int StartHour { get; set; }

        /// <summary>
        /// Resource is available on working days until this time 
        /// </summary>
        [JsonProperty("end_hour")]
        public int EndHour { get; set; }

        /// <summary>
        /// Allowed start quarters  
        /// </summary>
        [JsonProperty("start_quarters")]
        public int StartQuarters { get; set; }

        /// <summary>
        /// Price of one unit
        /// </summary>
        [JsonProperty("unit_price")]
        public string UnitPrice { get; set; }

        /// <summary>
        /// Comma-seprated unit names
        /// </summary>
        [JsonProperty("unit_names")]
        public string UnitNames { get; set; }

        /// <summary>
        /// Currency in which prices are expressed
        /// </summary>
        [JsonProperty("currency")]
        public string Currency { get; set; }


        /// <summary>
        /// Max. quantity allowed for a single reservation
        /// </summary>
        [JsonProperty("max_quantity_per_rental")]
        public int? MaxQuantityPerRental { get; set; }


        /// <summary>
        /// Minimum rental time expressed in hours
        /// </summary>
        [JsonProperty("min_rental_time")]
        public float MinRentalTime { get; set; }

        /// <summary>
        /// Maximum rental time expressed in hours
        /// </summary>
        [JsonProperty("max_rental_time")]
        public float? MaxRentalTime { get; set; }

        /// <summary>
        /// Resource setting Restrict starting times.
        /// </summary>
        [JsonProperty("start_times")]
        public string StartTimes { get; set; }

        /// <summary>
        /// Resource setting Min. time between reservation and rental.
        /// </summary>
        [JsonProperty("min_hours_to_rental")]
        public int MinHoursToRental { get; set; }

        /// <summary>
        /// Resource setting Max. time between reservation and rental. 
        /// </summary>
        [JsonProperty("max_days_to_rental")]
        public int MaxDaysToRental { get; set; }

    }

    /// <summary>
    /// Information about image
    /// </summary>
    public class Photo
    {
        /// <summary>
        ///Image Id
        /// </summary>
        [JsonProperty("id")]
        public int Id { get; set; }

        /// <summary>
        ///Image path
        /// </summary>
        [JsonProperty("path")]
        public string Path { get; set; }

        /// <summary>
        ///Image title
        /// </summary>
        [JsonProperty("title")]
        public string Title { get; set; }

    }

    /// <summary>
    /// properties
    /// </summary>
    public class Properties
    {
        /// <summary>
        ///No. of persons
        /// </summary>
        [JsonProperty("antall_personer")]
        public int NumberOfPersons { get; set; }

        /// <summary>
        /// Location
        /// </summary>
        [JsonProperty("location")]
        public string Location { get; set; }

        /// <summary>
        ///Description
        /// </summary>
        [JsonProperty("description")]
        public string Description { get; set; }
        
    }
}