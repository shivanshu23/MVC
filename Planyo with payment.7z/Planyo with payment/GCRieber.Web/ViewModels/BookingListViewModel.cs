﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GCRieber.API.Enums;
using GCRieber.API.Helpers;
using Newtonsoft.Json;

namespace GCRieber.API.ViewModels
{
    /// <summary>
    /// Booking List
    /// </summary>
    public class BookingListViewModel
    {
        /// <summary>
        /// Result property
        /// </summary>
        [JsonProperty("results")]
        public List<Booking> Results { get; set; } = new List<Booking>();
    }

    /// <summary>
    /// Result of the search
    /// </summary>
    public class Booking
    {
        /// <summary>
        /// Reservation ID of resource
        /// </summary>
        [JsonProperty("reservation_id")]
        public int ReservationId { get; set; }

        private ReservationStatus _status;
        /// <summary>
        /// Status of booking
        /// </summary>
        [JsonProperty("status")]
        public ReservationStatus Status
        {
            get { return _status; }
            set
            {
                // Set B to some new value
                _status = value;

                // Assign status text
                StatusText = value.GetDescription();
            }
        }

        /// <summary>
        /// Current status text
        /// </summary>
        public string StatusText { get; set; }

        /// <summary>
        /// Creation time of booking
        /// </summary>
        [JsonProperty("creation_time")]
        public DateTime CreationTime { get; set; }

        /// <summary>
        /// Quantity of resource
        /// </summary>
        [JsonProperty("quantity")]
        public int Quantity { get; set; }

        /// <summary>
        /// Start time of booking
        /// </summary>
        [JsonProperty("start_time")]
        public DateTime StartTime { get; set; }

        /// <summary>
        /// End time of booking
        /// </summary>
        [JsonProperty("end_time")]
        public DateTime EndTime { get; set; }

        /// <summary>
        /// Currency of price
        /// </summary>
        [JsonProperty("currency")]
        public string Currency { get; set; }

        /// <summary>
        /// First name of customer
        /// </summary>
        [JsonProperty("first_name")]
        public string FirstName { get; set; }

        /// <summary>
        /// Last name of customer
        /// </summary>
        [JsonProperty("last_name")]
        public string LastName { get; set; }

        /// <summary>
        /// User id of customer
        /// </summary>
        [JsonProperty("user_id")]
        public int User_id { get; set; }

        /// <summary>
        /// Email id of customer
        /// </summary>
        [JsonProperty("email")]
        public string Email { get; set; }
        
        /// <summary>
        /// Resource Id
        /// </summary>
        [JsonProperty("resource_id")]
        public int ResourceId { get; set; }

        /// <summary>
        /// Resource Name
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// Amount paid for booking
        /// </summary>
        [JsonProperty("amount_paid")]
        public float Amount_paid { get; set; }

        /// <summary>
        /// Total price of booking
        /// </summary>
        [JsonProperty("total_price")]
        public float Total_price { get; set; }

        /// <summary>
        /// Original price of booking
        /// </summary>
        [JsonProperty("original_price")]
        public float OriginalPrice { get; set; }
    }
}