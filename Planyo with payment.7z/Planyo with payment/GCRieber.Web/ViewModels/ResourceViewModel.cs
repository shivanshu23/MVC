﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace GCRieber.API.ViewModels
{
    /// <summary>
    /// Resource data view model
    /// </summary>
    public class ResourceDataViewModel
    {
        /// <summary>
        /// Total number of resources
        /// </summary>
        [JsonProperty("resource_count")]
        public int ResourceCount { get; set; }

        /// <summary>
        /// Max pages
        /// </summary>
        [JsonProperty("max_page")]
        public int MaxPage { get; set; }

        /// <summary>
        /// Resources
        /// </summary>
        [JsonProperty("resources")]
        public Dictionary<string, ResourceItemViewModel> Resources { get; set; } = new Dictionary<string, ResourceItemViewModel>();
    }

    /// <summary>
    /// Single Resource item
    /// </summary>
    public class ResourceItemViewModel
    {
        /// <summary>
        /// Resource Name
        /// </summary>
        [JsonProperty("name")]
        public string Name { get; set; }

        /// <summary>
        /// Resource id
        /// </summary>
        [JsonProperty("id")]
        public int Id { get; set; }

        /// <summary>
        /// Resource Name
        /// </summary>
        [JsonProperty("translated_name")]
        public string TranslatedName { get; set; }

        /// <summary>
        /// Resource-specific properties 
        /// </summary>
        [JsonProperty("properties")]
        public Properties Properties { get; set; }

        private List<Photo> _photos;
        /// <summary>
        /// Photos Array with photoId as key
        /// </summary>
        [JsonProperty("photos")]
        public dynamic Photos
        {
            get
            {
                return _photos;
            }
            set
            {
                if (value == null)
                {
                    _photos = new List<Photo>();
                }
                else
                {
                    List<Photo> photos = new List<Photo>();
                    foreach (KeyValuePair<string, object> val in value)
                    {
                        var photo = new Photo();
                        var item = (Dictionary<string, Object>)val.Value;
                        foreach (KeyValuePair<string, object> itm in item)
                        {
                            if (itm.Key.Contains("id"))
                                photo.Id = Convert.ToInt32(itm.Value);
                            if (itm.Key.Contains("path"))
                                photo.Path = Convert.ToString(itm.Value);
                            if (itm.Key.Contains("title"))
                                photo.Title = Convert.ToString(itm.Value);
                        }
                        photos.Add(photo);
                    }
                    _photos = photos;
                }

            }
        }
    }
}
