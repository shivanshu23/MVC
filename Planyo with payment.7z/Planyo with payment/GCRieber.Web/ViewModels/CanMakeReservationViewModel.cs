﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GCRieber.API.ViewModels
{
    /// <summary>
    /// Response of can make reservation
    /// </summary>
    public class CanMakeReservationViewModel
    {
        /// <summary>
        /// Check wheather the reservation is possible or not
        /// </summary>
        [JsonProperty("is_reservation_possible")]
        public bool IsReservationPossible { get; set; }      

        /// <summary>
        /// it states the problem time of not reservation
        /// </summary>
        [JsonProperty("problem_time")]
        public string ProblemTime { get; set; }

        /// <summary>
        /// it states the problem reason of not reservation
        /// </summary>
        [JsonProperty("reason")]
        public string Reason { get; set; }
    }
}
