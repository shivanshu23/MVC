﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GCRieber.API.ViewModels
{
    /// <summary>
    /// 
    /// </summary>
    public class UserLoginViewModel
    {
        /// <summary>
        /// Username
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// Password
        /// </summary>
        public string UserPassword { get; set; }
    }

    /// <summary>
    /// User View Model
    /// </summary>
    public class UserViewModel
    {
        /// <summary>
        /// USer ID
        /// </summary>
        public string UserId { get; set; }

        /// <summary>
        /// userName
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// userName
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Password
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// Email
        /// </summary>
        public string Mail { get; set; }
        
        /// <summary>
        /// Token
        /// </summary>
        public string Token { get; set; }
    }
}
