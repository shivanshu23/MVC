﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace GCRieber.API.ViewModels
{
    /// <summary>
    /// Update booking response
    /// </summary>
    public class UpdateBookingResponseViewModel
    {
        /// <summary>
        /// Warning Text
        /// </summary>
        [JsonProperty("warning_text")]
        public string WarningText { get; set; }

        /// <summary>
        /// Status of reservation
        /// </summary>
        [JsonProperty("status")]
        public int Status { get; set; }
    }

    /// <summary>
    /// Modify booking view model
    /// </summary>
    public class UpdateBookingViewModel
    {
        /// <summary>
        /// Start date and time
        /// </summary>
        public DateTime StartTime { get; set; }

        /// <summary>
        /// End date and time 
        /// </summary>
        public DateTime EndTime { get; set; }

        /// <summary>
        /// Resource id to modify
        /// </summary>
        public int ResourceId { get; set; }

        /// <summary>
        /// Location of the resource
        /// </summary>
        public string Location { get; set; }

    }
}
