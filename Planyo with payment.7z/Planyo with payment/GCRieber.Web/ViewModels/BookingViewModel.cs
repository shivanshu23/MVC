﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GCRieber.API.ViewModels
{
    /// <summary>
    /// Booking view model
    /// </summary>
    public class BookingViewModel
    {
        /// <summary>
        /// Start Date and time
        /// </summary>
        public DateTime StartDate { get; set; }

        /// <summary>
        /// End Date and time 
        /// </summary>
        public DateTime EndDate { get; set; }

        /// <summary>
        /// Quantity of Resource
        /// </summary>
        public int Quantity { get; set; }

        /// <summary>
        /// First Name
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Last Name
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Payment token 
        /// </summary>
        public string Token { get; set; }

    }
}
