﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GCRieber.API.ViewModels
{
    /// <summary>
    /// 
    /// </summary>
    public class RefundPaymentInfoViewModel
    {
        /// <summary>
        /// Reservation identifier
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// Payment detail identifier
        /// </summary>
        public string PaymentId { get; set; }

        /// <summary>
        /// Payment gateway identifier
        /// </summary>
        public string ChargeId { get; set; }
    }
}
