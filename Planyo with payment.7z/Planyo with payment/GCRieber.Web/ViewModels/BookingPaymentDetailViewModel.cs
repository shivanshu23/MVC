﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GCRieber.API.ViewModels
{
    /// <summary>
    /// Resource booking and payment info
    /// </summary>
    public class BookingPaymentInfoViewModel
    {
        /// <summary>
        /// Reservation identifier
        /// </summary>
        public int ReservationId { get; set; }

        /// <summary>
        /// Payment detail identifier
        /// </summary>
        public string PaymentId { get; set; }

        /// <summary>
        /// Payment gateway identifier
        /// </summary>
        public string ChargeId { get; set; }
    }


    /// <summary>
    /// Booking payment response
    /// </summary>
    public class BookingPaymentViewModel
    {
        /// <summary>
        /// Result property
        /// </summary>
        [JsonProperty("results")]
        public List<BookingPaymentsResponseViewModel> Results { get; set; } = new List<BookingPaymentsResponseViewModel>();
    }


    /// <summary>
    /// Booking response
    /// </summary>
    public class BookingPaymentsResponseViewModel
    {
        /// <summary>
        /// Payment ID of booking
        /// </summary>
        [JsonProperty("payment_id")]
        public int PaymentId { get; set; }

        /// <summary>
        /// Amount of booking
        /// </summary>
        [JsonProperty("amount")]
        public float Amount { get; set; }

        /// <summary>
        /// currency
        /// </summary>
        [JsonProperty("currency")]
        public string Currency { get; set; }

        /// <summary>
        /// Payment status of booking
        /// </summary>
        [JsonProperty("payment_status")]
        public int PaymentStatus { get; set; }

        /// <summary>
        /// Payment Mode
        /// </summary>
        [JsonProperty("payment_mode")]
        public int PaymentMode { get; set; }

        /// <summary>
        /// Charge ID of booking
        /// </summary>
        [JsonProperty("transaction_id")]
        public string TransactionId { get; set; }
    }
}
