﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GCRieber.API.ViewModels
{
    /// <summary>
    /// Booking rental info
    /// </summary>
    public class BookingRentalInfoViewModel
    {
        /// <summary>
        /// Currency 
        /// </summary>
        [JsonProperty("currency")]
        public string Currency { get; set; }

        /// <summary>
        /// Toatl price 
        /// </summary>
        [JsonProperty("total")]
        public float Total { get; set; }
    }
}
