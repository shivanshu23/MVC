﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GCRieber.API.ViewModels
{
    /// <summary>
    /// Add Booking payment details response
    /// </summary>
    public class BookingPaymentResponseViewModel
    {
        /// <summary>
        /// Reservation Status
        /// </summary>
        [JsonProperty("status")]
        public int Status { get; set; }

        /// <summary>
        /// payment id
        /// </summary>
        [JsonProperty("payment_id")]
        public string Payment_id { get; set; }
    }
}
