﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GCRieber.API.Enums;
using GCRieber.API.Helpers;
using Newtonsoft.Json;

namespace GCRieber.API.ViewModels
{
    /// <summary>
    /// Booking response
    /// </summary>
    public class BookingResponseViewModel
    {
        /// <summary>
        /// Reservation ID of resource
        /// </summary>
        [JsonProperty("reservation_id")]
        public int ReservationId { get; set; }

        private ReservationStatus _status;
        /// <summary>
        /// Status of booking
        /// </summary>
        [JsonProperty("status")]
        public ReservationStatus Status
        {
            get { return _status; }
            set
            {
                // Set B to some new value
                _status = value;

                // Assign status text
                StatusText = value.GetDescription();
            }
        }

        /// <summary>
        /// Current status text
        /// </summary>
        public string StatusText { get; set; }

        ///// <summary>
        ///// Text to be displayed to user
        ///// </summary>
        //[JsonProperty("user_text")]
        //public string UserText { get; set; }

        /// <summary>
        /// Resource Id
        /// </summary>
        [JsonProperty("resource_id")]
        public int ResourceId { get; set; }

        /// <summary>
        /// Currency
        /// </summary>
        [JsonProperty("currency")]
        public string Currency { get; set; }

        /// <summary>
        /// Properties
        /// </summary>
        [JsonProperty("properties")]
        public BookingResponseProperties Properties { get; set; }

        /// <summary>
        /// Total price of booking
        /// </summary>
        [JsonProperty("total_price")]
        public string TotalPrice { get; set; }

        /// <summary>
        /// Original price of booking
        /// </summary>
        [JsonProperty("original_price")]
        public string OriginalPrice { get; set; }

        /// <summary>
        /// Discount
        /// </summary>
        [JsonProperty("discount")]
        public string Discount { get; set; }
    }

    /// <summary>
    /// Booking response properites
    /// </summary>
    public class BookingResponseProperties
    {
        /// <summary>
        /// Rental Tax Rate
        /// </summary>
        [JsonProperty("rental_tax_rate")]
        public int RentalTaxRate { get; set; }
    }

    /// <summary>
    /// Booking information response
    /// </summary>
    public class BookingInformationResponseViewModel
    {
        /// <summary>
        /// Resource Id
        /// </summary>
        [JsonProperty("resource_id")]
        public int ResourceId { get; set; }

        /// <summary>
        /// User Id
        /// </summary>
        [JsonProperty("user_id")]
        public int UserId { get; set; }

        /// <summary>
        /// Start time of booking
        /// </summary>
        [JsonProperty("start_time")]
        public DateTime StartTime { get; set; }

        /// <summary>
        /// End time of booking
        /// </summary>
        [JsonProperty("end_time")]
        public DateTime EndTime { get; set; }

        private ReservationStatus _status;
        /// <summary>
        /// Status of booking
        /// </summary>
        [JsonProperty("status")]
        public ReservationStatus Status
        {
            get { return _status; }
            set
            {
                // Set B to some new value
                _status = value;

                // Assign status text
                StatusText = value.GetDescription();
            }
        }

        /// <summary>
        /// Current status text
        /// </summary>
        public string StatusText { get; set; }

        /// <summary>
        /// Quantity
        /// </summary>
        [JsonProperty("quantity")]
        public int Quantity { get; set; }
        
        /// <summary>
        /// Creation time of booking
        /// </summary>
        [JsonProperty("creation_time")]
        public DateTime CreationTime { get; set; }

        /// <summary>
        /// Currency
        /// </summary>
        [JsonProperty("currency")]
        public string Currency { get; set; }

        /// <summary>
        /// Email
        /// </summary>
        [JsonProperty("email")]
        public string Email { get; set; }

        /// <summary>
        /// First name
        /// </summary>
        [JsonProperty("first_name")]
        public string FirstName { get; set; }

        /// <summary>
        /// Last name
        /// </summary>
        [JsonProperty("last_name")]
        public string LastName { get; set; }

        /// <summary>
        /// User text 
        /// </summary>
        [JsonProperty("user_text")]
        public string UserText { get; set; }

        /// <summary>
        /// Amount paid for booking
        /// </summary>
        [JsonProperty("amount_paid")]
        public float AmountPaid { get; set; }

        /// <summary>
        /// Total price of booking
        /// </summary>
        [JsonProperty("total_price")]
        public float TotalPrice { get; set; }
        
        /// <summary>
        /// Original price of booking
        /// </summary>
        [JsonProperty("original_price")]
        public float OriginalPrice { get; set; }
        
    }
}
