﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GCRieber.API.Helpers;
using Newtonsoft.Json;

namespace GCRieber.API.ViewModels
{
    /// <summary>
    /// Resource search results
    /// </summary>
    public class ResourceSearchResultViewModel
    {
        private List<ResourceSearchItemViewModel> _resources;

        /// <summary>
        /// Resources
        /// </summary>
        [JsonProperty("results")]
        public dynamic Results
        {
            get
            {
                return _resources;
            }
            set
            {
                if (value != null)
                {
                    _resources = new List<ResourceSearchItemViewModel>();
                    var vtype = value.GetType().ToString();
                    if (vtype.Contains("SimpleJson.JsonArray"))
                    {
                        foreach (Dictionary<string, object> item in value)
                        {
                            var obj = new ResourceSearchItemViewModel();
                            if (item.ContainsKey("id"))
                                obj.id = Convert.ToInt32(item["id"]);
                            if (item.ContainsKey("is_unavailable"))
                                obj.is_unavailable = Convert.ToBoolean(item["is_unavailable"]);
                            if (item.ContainsKey("name"))
                                obj.name = Convert.ToString(item["name"]);
                            if (item.ContainsKey("translated_name"))
                                obj.translated_name = Convert.ToString(item["translated_name"]);
                            if (item.ContainsKey("photos"))
                            {
                                obj.Photos = item["photos"];
                            }
                            _resources.Add(obj);
                        }
                    }
                    else if (vtype.Contains("System.Collections.Generic.Dictionary"))
                    {
                        foreach (KeyValuePair<string, object> item in value)
                        {
                            var obj = (Dictionary<string, object>)item.Value;
                            var searchItem =
                                AppHelper.DictionaryToObject<ResourceSearchItemViewModel>(obj, new[] { "photos" });
                            if (obj.ContainsKey("photos"))
                            {
                                searchItem.Photos = obj["photos"];
                            }
                            _resources.Add(searchItem);
                        }
                    }
                }
                else
                {
                    _resources = new List<ResourceSearchItemViewModel>();
                }
            }
        }
    }

    /// <summary>
    /// Single Resource item
    /// </summary>
    public class ResourceSearchItemViewModel
    {
        /// <summary>
        /// Resource Name
        /// </summary>
        public string name { get; set; }

        /// <summary>
        /// Resource id
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// Resource Name
        /// </summary>
        public string translated_name { get; set; }

        /// <summary>
        /// Resource availablity
        /// </summary>
        public bool is_unavailable { get; set; }

        private List<Photo> _photos;
        /// <summary>
        /// Photos Array with photoId as key
        /// </summary>
        [JsonProperty("photos")]
        public dynamic Photos
        {
            get
            {
                return _photos;
            }
            set
            {
                if (value == null)
                {
                    _photos = new List<Photo>();
                }
                else
                {
                    List<Photo> photos = new List<Photo>();
                    foreach (KeyValuePair<string, object> val in value)
                    {
                        var photo = new Photo();
                        var item = (Dictionary<string, Object>)val.Value;
                        foreach (KeyValuePair<string, object> itm in item)
                        {
                            if (itm.Key.Contains("id"))
                                photo.Id = Convert.ToInt32(itm.Value);
                            if (itm.Key.Contains("path"))
                                photo.Path = Convert.ToString(itm.Value);
                            if (itm.Key.Contains("title"))
                                photo.Title = Convert.ToString(itm.Value);
                        }
                        photos.Add(photo);
                    }
                    _photos = photos;
                }

            }
        }

        ///// <summary>
        ///// Range Search
        ///// </summary>
        //public Dictionary<string, DateTime> Ranges { get; set; } = new Dictionary<string, DateTime>();

    }

    ///// <summary>
    ///// Range
    ///// </summary>
    //public class Ranges
    //{
    //    /// <summary>
    //    /// Resource Name
    //    /// </summary>
    //    [JsonProperty("name")]
    //    public DateTime StartDate { get; set; }

    //    /// <summary>
    //    /// Resource Name
    //    /// </summary>
    //    [JsonProperty("name")]
    //    public DateTime EndDate { get; set; }

    //    /// <summary>
    //    /// Price
    //    /// </summary>
    //    [JsonProperty("price")]
    //    public float Price { get; set; }

    //}

    /// <summary>
    /// Default search view model
    /// </summary>
    public class ResourceSearchItemDefaultViewModel
    {
        /// <summary>
        /// Resource Name
        /// </summary>
        public string name { get; set; }

        /// <summary>
        /// Resource id
        /// </summary>
        public int id { get; set; }

        /// <summary>
        /// Resource Name
        /// </summary>
        public string translated_name { get; set; }

        /// <summary>
        /// Resource availablity
        /// </summary>
        public bool is_unavailable { get; set; }


        /// <summary>
        /// Photos Array with photoId as key
        /// </summary>
        [JsonProperty("photos")]
        public List<Photo> Photos { get; set; }
    }
}
