﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.FileProviders;
using Microsoft.WindowsAzure.Storage.Blob;

namespace GCRieber.API.Helpers.AzureBlobHelper
{
    /// <summary>
    /// Blob directory contents
    /// </summary>
    public class AzureBlobDirectoryContents : IDirectoryContents
    {
        private readonly List<IListBlobItem> _blobs = new List<IListBlobItem>();

        /// <summary>
        /// 
        /// </summary>
        public bool Exists { get; set; }

        /// <summary>
        /// Ctor
        /// </summary>
        /// <param name="blob"></param>
        public AzureBlobDirectoryContents(CloudBlobDirectory blob)
        {
            BlobContinuationToken continuationToken = null;

            do
            {
                var response = blob.ListBlobsSegmented(continuationToken);
                continuationToken = response.ContinuationToken;
                _blobs.AddRange(response.Results);
            }
            while (continuationToken != null);
            Exists = _blobs.Count > 0;
        }

        /// <summary>
        /// Enumerate on all directory files
        /// </summary>
        /// <returns></returns>
        public IEnumerator<IFileInfo> GetEnumerator()
        {
            return _blobs.Select(blob => new AzureBlobFileInfo(blob)).GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}

