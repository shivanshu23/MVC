﻿using Microsoft.Extensions.Configuration;
using Stripe;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GCRieber.API.Helpers.Stripe
{
    /// <summary>
    /// Payment helperk
    /// </summary>
    public class PaymentHelper
    {
        /// <summary>
        /// Stripe Code For Planyo
        /// </summary>
        public readonly int StripeCodeForPlanyo = 56;

        #region Private variables
        private string ApiKey { get; set; }
        #endregion

        /// <summary>
        /// Ctor
        /// </summary>
        /// <param name="configuration"></param>
        public PaymentHelper(IConfiguration configuration)
        {
            ApiKey = configuration["Stripe:ApiKey"];
        }

        /// <summary>
        /// Make payment
        /// </summary>
        /// <param name="token"></param>
        /// <param name="amount"></param>
        /// <param name="Currency"></param>
        /// <param name="receiptEmail"></param>        
        /// <returns></returns>
        public Charge MakePayment(string token, long amount, string Currency, string receiptEmail)
        {
            StripeConfiguration.SetApiKey(ApiKey);
            var options = new ChargeCreateOptions
            {
                Amount = amount,
                Currency = Currency,
                SourceId = token,
                ReceiptEmail = receiptEmail
            };
            var service = new ChargeService();
            Charge charge = service.Create(options);
            return charge;
        }

        /// <summary>
        /// Update payment charge details
        /// </summary>
        /// <param name="chargeId"></param>
        /// <param name="description"></param>
        /// <param name="metaData"></param>
        /// <returns></returns>
        public Charge UpdatePaymentDetails(string chargeId, string description, Dictionary<string, string> metaData)
        {
            StripeConfiguration.SetApiKey(ApiKey);
            var options = new ChargeUpdateOptions
            {
                Description = description,
                Metadata = metaData 
                
            };
            var service = new ChargeService();
            Charge charge = service.Update(chargeId, options);
            return charge;
        }

        /// <summary>
        /// Make Refund
        /// </summary>
        /// <param name="amount"></param>
        /// <param name="chargeID"></param>        
        /// <returns></returns>
        public Refund MakeRefund(long amount, string chargeID)
        {
            StripeConfiguration.SetApiKey(ApiKey);
            var options = new RefundCreateOptions
            {
                Amount = amount,
                Reason = RefundReasons.RequestedByCustomer,
                ChargeId= chargeID
            };
            var service = new RefundService();
            Refund refund = service.Create(options);
            return refund;
        }

        /// <summary>
        /// Update refund charge details
        /// </summary>
        /// <param name="refundId"></param>
        /// <param name="metaData"></param>
        /// <returns></returns>
        public Refund UpdateRefundDetails(string refundId, Dictionary<string, string> metaData)
        {
            StripeConfiguration.SetApiKey(ApiKey);
            var options = new RefundUpdateOptions 
            {
                Metadata = metaData
            };

            var service = new RefundService();
            Refund refund = service.Update(refundId, options);

            var service2 = new RefundService();
            Refund refund2 = service.Get(refundId);

            return refund;
        }
    }
}
