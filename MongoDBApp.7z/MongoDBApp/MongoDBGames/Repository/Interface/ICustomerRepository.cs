﻿using MongoDBGames.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MongoDBGames.Repository
{
    public interface ICustomerRepository : IRepository<Customer>
    {
        IEnumerable<Customer> GetAllCustomers();
        Customer GetCustomerByName(string name);
        void CreateCustomer(Customer cust);
        Customer UpdateCustomer(string name, Customer cust);
        Customer DeleteCustomer(string name);
    }
}
