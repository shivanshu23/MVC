﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;

namespace MongoDBGames.Repository
{
    public interface IRepository<T> where T: class
    {
        IEnumerable<T> GetAll();
        T GetByName(Expression<Func<T, bool>> expression);
        void Create(T item);
        T Update(Expression<Func<T, bool>> expression, UpdateDefinition<T> update);
        T Delete(Expression<Func<T, bool>> expression);
    }
}
