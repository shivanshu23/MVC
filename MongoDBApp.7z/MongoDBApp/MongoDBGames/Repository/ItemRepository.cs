﻿using System.Collections.Generic;
using MongoDB.Bson;
using MongoDB.Driver;
using MongoDBGames.Model;

namespace MongoDBGames.Repository
{
    public class ItemRepository : Repository<Items>, IItemRepository
    {
       private readonly ApplicationContext _context;

        public ItemRepository(ApplicationContext context) : base(context, "Items")
        {
            _context = context;
        }

        public IEnumerable<ItemsViewModel> GetAllItems()
        {
            var data= GetAll();
            List<ItemsViewModel> list = new List<ItemsViewModel>();          

            foreach (var i in data)
            {
                var obj = new ItemsViewModel();

                obj.Id = i.Id.ToString();
                obj.ItemName = i.ItemName;
                obj.Price = i.Price;
                obj.QuantityAvailable = i.QuantityAvailable;

                list.Add(obj);
             }

            return list;
        }

        public ItemsViewModel GetItemById(ObjectId itemId)
        {
            var data = GetByName(x => x.Id == itemId);
            
                var obj = new ItemsViewModel();
                obj.Id = data.Id.ToString();
                obj.ItemName = data.ItemName;
                obj.Price = data.Price;
                obj.QuantityAvailable = data.QuantityAvailable;            

            return obj;
        }      

        public void CreateItem(Items item)
        {
             Create(item);
        }

        public Items UpdateItem(ObjectId id, Items item)
        {
            var updateDefinition = Builders<Items>.Update
                   .Set(x => x.Id, item.Id)
                   .Set(x => x.ItemName, item.ItemName)
                   .Set(x => x.Price, item.Price)
                   .Set(x => x.QuantityAvailable, item.QuantityAvailable);


            return Update(x => x.Id == id, updateDefinition);
        }

        public Items DeleteItem(ObjectId id)
        {
            return Delete(x => x.Id == id);
        }
    }
}