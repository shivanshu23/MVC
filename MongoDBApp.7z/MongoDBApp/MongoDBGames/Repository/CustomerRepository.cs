﻿using MongoDB.Driver;
using MongoDBGames.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MongoDBGames.Repository
{
    public class CustomerRepository : Repository<Customer>, ICustomerRepository
    {
        private readonly ApplicationContext _context;
        public CustomerRepository(ApplicationContext context) : base(context, "Customers")
        {
            _context = context;
        }

        public IEnumerable<Customer> GetAllCustomers()
        {
            return GetAll();
        }

        public Customer GetCustomerByName(string name)
        {
            return GetByName(x => x.Name == name);
        }

        public void CreateCustomer(Customer cust)
        {
            Create(cust);
        }  
        
        public Customer UpdateCustomer(string name, Customer cust)
        {
            var updateDefinition = Builders<Customer>.Update
                   .Set(x => x.CustomerID, cust.CustomerID)
                   .Set(x => x.Name, cust.Name)
                   .Set(x => x.Country, cust.Country);

            return Update(x => x.Name == name, updateDefinition);
        }

        public Customer DeleteCustomer(string name)
        {
            return Delete(x => x.Name == name);
        }
    }
}
