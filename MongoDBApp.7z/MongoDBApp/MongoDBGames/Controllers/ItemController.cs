﻿using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using MongoDBGames.Model;
using MongoDBGames.Repository;

namespace MongoDBGames.Controllers
{
    [Produces("application/json")]
    [Route("api/Item")]
    public class ItemController : Controller
    {
        private readonly IItemRepository _itemRepository;

        public ItemController(IItemRepository itemRepository)
        {
            _itemRepository = itemRepository;
        }

        // GET: api/Item
        [HttpGet]
        public IActionResult Get()
        {
            return new ObjectResult(_itemRepository.GetAllItems());
        }

        // GET: api/Item/name
        [HttpGet("{id}")]
        public IActionResult Get(string id)
        {
            return new ObjectResult(_itemRepository.GetItemById(new ObjectId(id)));           
        }

        // POST: api/Item
        [HttpPost]
        public void Post([FromBody]Items item)
        {
            var itm = new Items()
            {
                ItemName = item.ItemName,
                Price = item.Price,
                QuantityAvailable = item.QuantityAvailable
            };           

             _itemRepository.CreateItem(itm);
        }

        // PUT: api/Game/5
        [HttpPut("{id}")]
        public IActionResult Put(string id, [FromBody]ItemsViewModel item)
        {
            var itm = new Items();
            itm.Id = new ObjectId(id);
            itm.ItemName = item.ItemName;
            itm.Price = item.Price;
            itm.QuantityAvailable = item.QuantityAvailable;

            return new ObjectResult(_itemRepository.UpdateItem(new ObjectId(id), itm));
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public IActionResult Delete(string id)
        {
            return new ObjectResult(_itemRepository.DeleteItem(new ObjectId(id)));
        }
    }
}
