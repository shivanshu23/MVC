﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MongoDBGames.Model;
using MongoDBGames.Repository;

namespace MongoDBGames.Controllers
{
    [Produces("application/json")]
    [Route("api/Customer")]
    public class CustomerController : Controller
    {
        private readonly ICustomerRepository _customerRepository;
        public CustomerController(ICustomerRepository customerRepository)
        {
            _customerRepository = customerRepository;
        }

        // GET: api/Game
        [HttpGet]
        public IActionResult Get()
        {
            return new ObjectResult(_customerRepository.GetAllCustomers());
        }

        // GET: api/Game/name
        [HttpGet("{name}")]
        public IActionResult Get(string name)
        {
            return new ObjectResult(_customerRepository.GetCustomerByName(name));
        }

        // POST: api/Customer
        [HttpPost]
        public void Post([FromBody]Customer cust)
        {
            _customerRepository.CreateCustomer(cust);
        }

        // PUT: api/Customer/5
        [HttpPut("{name}")]
        public IActionResult Put(string name, [FromBody]Customer cust)
        {
            return new ObjectResult(_customerRepository.UpdateCustomer(name, cust));
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{name}")]
        public IActionResult Delete(string name)
        {
            return new ObjectResult(_customerRepository.DeleteCustomer(name));
        }
    }
}