﻿using Microsoft.Extensions.Options;
using MongoDB.Driver;

namespace MongoDBGames.Model
{
    public class ApplicationContext
    {
        public readonly IMongoDatabase _db;
        public ApplicationContext(IOptions<Settings> options) 
        {
            var client = new MongoClient(options.Value.ConnectionString);
            _db = client.GetDatabase(options.Value.Database);
        }
    }
}