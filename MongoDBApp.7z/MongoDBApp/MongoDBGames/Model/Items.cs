﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MongoDBGames.Model
{
    public class Items  
    {
        [BsonId]
        public ObjectId Id { get; set; }

        [BsonElement("itemName")]
        public string ItemName { get; set; }

        [BsonElement("price")]
        public int Price { get; set; }

        [BsonElement("quantityAvailable")]
        public int QuantityAvailable { get; set; }
    }
}
