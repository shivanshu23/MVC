﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication8.Models
{
    public class Employee
    {
            public dynamic ID
            {
                get;
                set;
            }
            public dynamic Name
            {
                get;
                set;
            }
            public dynamic Designation
            {
                get;
                set;
            }
        }
}