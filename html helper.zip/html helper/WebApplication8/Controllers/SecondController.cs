﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication8.Models;

namespace WebApplication8.Controllers
{
    public class SecondController : Controller
    {
        // GET: Second
        public ActionResult IndexDynamic()
        {
            Employee employee = new Employee()
            {

                ID = "stw",
                Name = 1235345,
                Designation = "Singer"
            };

            //passing the Employee obj to view

            return View(employee);
        }

        public ActionResult IndexStrong()
        {
            EmployeeStrong employee = new EmployeeStrong()
            {
                ID = 101,
                Name = "Anoop Kumar Sharma",
                Designation = "Software Engineer"
            };
            //Passing the Employee obj to View    
            return View(employee);
        }

        public ActionResult Parameter(string id)
        {
            ViewBag.id = id;
            return View();
        }
    }
}