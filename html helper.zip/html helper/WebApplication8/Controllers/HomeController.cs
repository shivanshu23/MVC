﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication8.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            ViewBag.Name = "Shivanshu";
            return View();
        }

        public ActionResult AboutUs()
        {
            
            return View();
        }

        public ActionResult ContactUs()
        {
            
            return View();
        }

        public ActionResult data()
        {
            ViewData["viewdata1"] = DateTime.Now.ToString();

            ViewBag.viewbag1 = DateTime.Now;

            return View(); 
        }

        public ActionResult temp()    //we can send data from one controller to other
        {
            TempData["mydata"] = DateTime.Now.ToString();
            return RedirectToAction("Index1");

        }

        public ActionResult Index1()
        {
            TempData.Keep(); //this will keep the data on Refresh
            return View();

        }






    }
}